<?php
include_once("sec.php");
set_time_limit (3600);
$adder=$me_uid;
$sw_tbl=injection_replace($_POST["sw_tbl"]);
?>
<div class="box box-default">
     <div class="box-header with-border">
         <h3 class="box-title"><?=$sw_legend;?></h3>
     </div>
     <div class="box-body pad">
	<? if(empty($mes)){?>
		<form id="sw_ins" class="form-horizontal" method="post">
			<p><?=$sw_details;?></p>
			<div class="box-body">
				<div class="form-group">
         			<label class="col-sm-2 control-label" for="sw_tbl"><?=$sw_tbls;?></label>
         			<div class="col-sm-10">
         				<select id="sw_tbl" class="form-control" data-ejb="1" name="sw_tbl">
         					<option></option>
							<option <? if($sw_tbl=="ali_rasekhun"){?>selected="selected" <? }?>="" value="ali_rasekhun">راسخون</option>
         				</select>
         			</div>                  
        		 </div>
        	</div> 
				<div id="submitbox" class="box-footer">
         			<input class="btn btn-info pull-left" name="sw_post" type="submit" value="<?=$sw_post;?>" />
       			</div>
		</form>
	 <? }else{ ?>
	 <div><? echo $mes;?></div>
     <? }?>
	 </div>
	 <?
	 if(isset($_POST["sw_post"])){
	 	$i=0;
		$result=$db->query("select * from nlp_stopwords");
		while($OR=$result->fetch(PDO::FETCH_OBJ)){
			$sw[$i]=$OR->word_text;
			$i++;
		}
		$result=$db->query("select id,q from $sw_tbl where rem='0' limit 0,20000");
		while($OR=$result->fetch(PDO::FETCH_OBJ)){
			$id=$OR->id;
			//echo $OR->q."<br>";
			$q=str_replace("?","",$OR->q);
			$q=str_replace("؟","",$q);
			$q=str_replace("ك","ک",$q);
			$q=str_replace("ي","ی",$q);
			$q=str_replace("،"," ",$q);
			$q=str_replace("("," ",$q);
			$q=str_replace(")"," ",$q);
			$q=str_replace("«"," ",$q);
			$q=str_replace("»"," ",$q);
			$q=str_replace("."," ",$q);
			$q=str_replace("!"," ",$q);
			$q=str_replace("-"," ",$q);
			$q=str_replace("؛"," ",$q);
			$q=str_replace("]"," ",$q);
			$q=str_replace("["," ",$q);
			$q=str_replace("}"," ",$q);
			$q=str_replace("{"," ",$q);
			$q=str_replace("ـ"," ",$q);
			$q=str_replace("<"," ",$q);
			$q=str_replace(">"," ",$q);
			$q=str_replace("|"," ",$q);
			$q=str_replace("×"," ",$q);
			$q=str_replace("+"," ",$q);
			$q=str_replace(":"," ",$q);
			$q=str_replace("�","",$q);
			$q=str_replace("ً","",$q);
			$q=str_replace("ٌ","",$q);
			$q=str_replace("ٍ","",$q);
			$q=str_replace("َ","",$q);
			$q=str_replace("ُ","",$q);
			$q=str_replace("ِ","",$q);
			$q=str_replace("ّ","",$q);
			$q=str_replace(","," ",$q);
			$q=str_replace("."," ",$q);
			$q=str_replace("/"," ",$q);
			$qstr=explode(" ",$q);
			$q="";
			$j=0;
			foreach($qstr as $s){
				
				if(in_array($s,$sw)){
					$s="";
				}else{
					$q.=trim($s)." ";
				}
			}
			$q=trim($q);
			$result3=$db->query("insert into nlp_questions (question,tbl,tbl_qid) values ('$q','$sw_tbl','$id') ");
			$result2=$db->query("update ali_rasekhun set rem='1' where id='$id'");
			
		}
	}

	 ?>
</div>
	
<script>
$(function(){
	
	$('form[id^=sw_ins]').bind('submit',function(event){
		var mes=0;
		var lab="";
		$('form[id^=sw_ins] *').each(function(){
			if(!$(this).val()&&$(this).attr("data-ejb")==1)
			{
				$(this).addClass('bg-yellow-active');
				mes=1;
			}
		});
		if(mes==1){
			$('.modal-warning .modal-body p').html('<?php echo $form_nofill ;?>');
            $('.modal-warning').addClass('in');
            $('.modal-warning').css("display","block");
			return false;
		}else{
			return true;
		}
	});
});
</script>