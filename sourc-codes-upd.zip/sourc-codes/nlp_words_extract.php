<?php
include_once("sec.php");
set_time_limit (3600);
$adder=$me_uid;
$sw_tbl=injection_replace($_POST["sw_tbl"]);
?>
<div class="box box-default">
     <div class="box-header with-border">
         <h3 class="box-title"><?=$sw_legend;?></h3>
     </div>
     <div class="box-body pad">
	<? if(empty($mes)){?>
		<form id="sw_ins" method="post" class="form-horizontal">
			<p><?=$sw_details;?></p>
			<div class="box-body">
				<div class="form-group">
         			<label for="sw_tbl" class="col-sm-2 control-label"><?=$sw_tbls;?></label>
         			<div class="col-sm-10">
         				<select id="sw_tbl" name="sw_tbl"  data-ejb="1"  class="form-control">
         					<option></option>
							<option value="ali_rasekhun" <? if($sw_tbl=="ali_rasekhun"){?>selected="selected"<? }?>>راسخون</option>
         				</select>
         			</div>                  
        		 </div>
        	</div> 
				<div class="box-footer" id="submitbox">
         			<input type="submit"  class="btn btn-info pull-left" name="sw_post" value="<?=$sw_post;?>">
       			</div>
		</form>
	 <? }else{ ?>
	 <div><? echo $mes;?></div>
     <? }?>
	 </div>
	 <?
	 if(isset($_POST["sw_post"])){
	 	$i=0;
		$result=$db->query("select * from nlp_stopwords");
		while($OR=$result->fetch(PDO::FETCH_OBJ)){
			$sw[$i]=$OR->word_text;
			$i++;
		}

		$result=$db->query("select question,id from nlp_questions where tbl='$sw_tbl' and stat='0' limit 0,10000");
		while($OR=$result->fetch(PDO::FETCH_OBJ)){
			$id=$OR->id;
			$q_sw=$OR->question;
			$qstr=explode(" ",$q_sw);
			$j=0;
			foreach($qstr as $s){
			  if(!in_array($s,$sw)){
				$s=trim($s);				
				$result2=$db->query("select qid,word_id from nlp_words where word_text='$s'");
				$OR2=$result2->fetch(PDO::FETCH_OBJ);
				$qid=$OR2->qid;
				$word_id=$OR2->word_id;
				if(empty($word_id)){
					$db->query("insert into nlp_words (word_text,qid) values ('$s','$id')");
				}else{
					$qid=$qid.",".$id;
					$db->query("update nlp_words set qid='$qid',word_tf=word_tf+1 where word_id='$word_id'");
				}
			  }
			}
			$db->query("update nlp_questions set stat='1' where id='$id'");			
		}
	}

	 ?>
</div>
	
<script>
$(function(){
	
	$('form[id^=sw_ins]').bind('submit',function(event){
		var mes=0;
		var lab="";
		$('form[id^=sw_ins] *').each(function(){
			if(!$(this).val()&&$(this).attr("data-ejb")==1)
			{
				$(this).addClass('bg-yellow-active');
				mes=1;
			}
		});
		if(mes==1){
			$('.modal-warning .modal-body p').html('<?php echo $form_nofill ;?>');
            $('.modal-warning').addClass('in');
            $('.modal-warning').css("display","block");
			return false;
		}else{
			return true;
		}
	});
});
</script>