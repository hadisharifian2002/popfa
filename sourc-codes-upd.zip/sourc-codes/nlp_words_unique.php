<?php
set_time_limit (3600);
$result=$db->query("select qid,word_id from nlp_words where stat='0'");
while($OR=$result->fetch(PDO::FETCH_OBJ)){
	$qid2=explode(",",$OR->qid);
	$qid2=array_unique($qid2);
	$word_df=count($qid2);
	$qid=implode(",",$qid2);
	$word_id=$OR->word_id;
	$result2=$db->query("update nlp_words set qid='$qid',word_df='$word_df',stat='1' where word_id='$word_id'");
}
?>