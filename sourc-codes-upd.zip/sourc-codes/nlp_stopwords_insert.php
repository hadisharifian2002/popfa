<?php
include_once("sec.php");
$adder=$me_uid;
?>
<div class="box box-default">
     <div class="box-header with-border">
         <h3 class="box-title"><?=$sw_legend;?></h3>
     </div>
     <div class="box-body pad">
	<? if(empty($mes)){?>
		<form id="sw_ins" method="post" class="form-horizontal">
			<p><?=$sw_details;?></p>
			<div class="box-body">
				<div class="form-group">
		 			<textarea name="textarea" id="mytextarea" data-ejb="1"><?=$textarea;?></textarea>
	   			</div>
        	</div> 
				<div class="box-footer" id="submitbox">
         			<input type="submit"  class="btn btn-info pull-left" name="sw_post" value="<?=$sw_post;?>">
       			</div>
		</form>
	 <? }else{ ?>
	 <div><? echo $mes;?></div>
     <? }?>
	 </div>
	 <?
	 if(isset($_POST["textarea"])){
	$stw=injection_replace($_POST["textarea"]);
	$stws=explode("\n",$stw);
	foreach ($stws as $s)
	{
        $result=$db->query("select count(*) as cnt from nlp_stopwords where word_text='$s'");
        $OR=$result->fetch(PDO::FETCH_OBJ);
        $cnt=$OR->cnt;
        if($cnt==0){
        	$word_text=trim($s);
        	$word_merged=str_replace(" ","",$word_text);
        	$result2=$db->query("insert into nlp_stopwords (word_text,word_merged) values ('$word_text','$word_merged')");
        	echo $s."<br>";
        }
	}   
	}

	 ?>
</div>
	
<script>
$(function(){
	
	$('form[id^=sw_ins]').bind('submit',function(event){
		var mes=0;
		var lab="";
		$('form[id^=sw_ins] *').each(function(){
			if(!$(this).val()&&$(this).attr("data-ejb")==1)
			{
				$(this).addClass('bg-yellow-active');
				mes=1;
			}
		});
		if(mes==1){
			$('.modal-warning .modal-body p').html('<?php echo $form_nofill ;?>');
            $('.modal-warning').addClass('in');
            $('.modal-warning').css("display","block");
			return false;
		}else{
			return true;
		}
	});
});
</script>