<?php
set_time_limit (3600);
$result=$db->query("select word_df,word_id from nlp_words where stat='1'");
while($OR=$result->fetch(PDO::FETCH_OBJ)){
	$word_df=$OR->word_df;
	$word_id=$OR->word_id;
	$word_idf=log(60469/$word_df);
	$result2=$db->query("update nlp_words set word_idf='$word_idf',stat='2' where word_id='$word_id'");
}
?>