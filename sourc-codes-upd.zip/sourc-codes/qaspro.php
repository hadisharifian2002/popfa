<?
$q=$_POST['q'];
$maxlen=500;
$minq=10;
?>
<div class="box">
	<div class="box-header">
    	<h3 class="box-title">پیکره پرسش و پاسخ فارسی </h3>
    </div>
	<div class="box-body">
	<form method="post" style="text-align:center">
		<input type="text" class="form-control" name="q" placeholder="پرسش خود را اینجا بنویسید..." value="<?=$q;?>">
		<br><input type="submit"  class="btn btn-info pull-left" name="post" value="پاسخ را بیاب">	
	</form>
	<br><hr>
	<div class="row">
		
<?
if(isset($_POST['q'])){
	$i=0;
	$q=$_POST['q'];
	$result=$db->query("select * from nlp_stopwords");
	while($OR=$result->fetch(PDO::FETCH_OBJ)){
		$sw[$i]=$OR->word_text;
		$i++;
	}

	$q=str_replace("?","",$q);
	$q=str_replace("؟","",$q);
	$q=str_replace("ك","ک",$q);
	$q=str_replace("ي","ی",$q);
	$q=str_replace("،"," ",$q);
	$q=str_replace("("," ",$q);
	$q=str_replace(")"," ",$q);
	$q=str_replace("«"," ",$q);
	$q=str_replace("»"," ",$q);
	$q=str_replace("."," ",$q);
	$q=str_replace("!"," ",$q);
	$q=str_replace("-"," ",$q);
	$q=str_replace("؛"," ",$q);
	$q=str_replace("]"," ",$q);
	$q=str_replace("["," ",$q);
	$q=str_replace("}"," ",$q);
	$q=str_replace("{"," ",$q);
	$q=str_replace("ـ"," ",$q);
	$q=str_replace("<"," ",$q);
	$q=str_replace(">"," ",$q);
	$q=str_replace("|"," ",$q);
	$q=str_replace("×"," ",$q);
	$q=str_replace("+"," ",$q);
	$q=str_replace(":"," ",$q);
	$q=str_replace("ً","",$q);
	$q=str_replace("ٌ","",$q);
	$q=str_replace("ٍ","",$q);
	$q=str_replace("َ","",$q);
	$q=str_replace("ُ","",$q);
	$q=str_replace("ِ","",$q);
	$q=str_replace("ّ","",$q);
	$q=str_replace(","," ",$q);
	$q=str_replace("."," ",$q);
	$q=str_replace("/"," ",$q);
	$qstr=explode(" ",$q);
	$q="";
	$ql=0;
	$que="where (";
	foreach($qstr as $s){
		if(in_array($s,$sw)){
			$s="";
		}else{
			$que.="word_text='".trim($s)."' or ";
			$ql++;
		}
	}
	$que=substr($que,0,strlen($que)-4);
	if($ql>0){$que.=") order by word_tfidf desc";}else{$que="where stat='5'";}
	$result=$db->query("select word_text from nlp_words $que");
	while($OR=$result->fetch(PDO::FETCH_OBJ)){
		$words[]=$OR->word_text;
	}
	$wordsorig=$words;
	$q="+".implode(" +",$words);
?>
		
		<div class="col-md-6">
			<div class="callout callout-info">
				<h4>جستجو بر اساس پرسش ها</h4>
			</div>			
<?
	$j=1;
	$qcnt=0;
	$newwords=array();
while($qcnt<$minq){
	$qneed=$minq-$qcnt;
	$thisstep=0;
	$result=$db->query("select question,answer,tbl,tbl_qid,MATCH (question) AGAINST('$q' IN BOOLEAN MODE) as score from nlp_questions where MATCH (question) AGAINST('$q' IN BOOLEAN MODE) order by score desc limit 0,$qneed");
	while($OR=$result->fetch(PDO::FETCH_OBJ)){
		$tbl=$OR->tbl;
		$id=$OR->tbl_qid;
		$result2=$db->query("select q,ans from $tbl where id='$id'");
		$OR2=$result2->fetch(PDO::FETCH_OBJ);
		$qu=$OR2->q;
		$ans=$OR2->ans;
		$id=$OR->id;
		$qu=str_replace("ك","ک",$qu);
		$qu=str_replace("ي","ی",$qu);
		$ans=str_replace("ك","ک",$ans);
		$ans=str_replace("ي","ی",$ans);
		foreach($words as $rw){
			$qu=str_replace($rw,"<span class='text-orange'>$rw</span>",$qu);
			$ans=str_replace($rw,"<span class='text-orange'>$rw</span>",$ans);
		}
		foreach($newwords as $rw){
			$qu=str_replace($rw,"<span class='text-orange'>$rw</span>",$qu);
			$ans=str_replace($rw,"<span class='text-orange'>$rw</span>",$ans);
		}

		$len=strlen($qu)+strlen($ans);
		if($len<$maxlen){
?>
			<div>
				<p class="text-aqua"><?=$j.$id;?><i class="fa fa-fw fa-question-circle"></i><?=$qu;?></p>
				<p><?=$ans;?></p>
				<p><i class="fa fa-fw fa-tripadvisor"></i><?=$OR->score;?></p>
			</div>
		<? }else{
						
		 ?>
		 	<div id="dlq_<?=$id;?>">
				<p class="text-aqua"><?=$j;?><i class="fa fa-fw fa-question-circle"></i><?=$qu;?></p>
				<p><?=$ans;?></p>
				<p><button type="button" id="blq_<?=$id;?>" class="btn btn-default btn-xs">نمایش مختصر</button></p>
				<p><i class="fa fa-fw fa-tripadvisor"></i><?=$OR->score;?></p>
			</div>
			<div id="dsq_<?=$id;?>">
				<? if(strlen($qu)<$maxlen){
						$l=$maxlen-strlen($qu);
						$ans=substr($ans,0,$l)." ...";
				?>
					<p class="text-aqua"><?=$j;?><i class="fa fa-fw fa-question-circle"></i><?=$qu;?></p>
					<p><?=$ans;?></p>
					<p><button type="button" id="bsq_<?=$id;?>" class="btn btn-default btn-xs">نمایش کامل</button></p>
				<? }else{
						$qu=substr($qu,0,$maxlen)." ...";
				?>
					<p class="text-aqua"><?=$j;?><i class="fa fa-fw fa-question-circle"></i><?=$qu;?></p>
					<p><button type="button" id="bsq_<?=$id;?>" class="btn  btn-default btn-xs">نمایش کامل</button></p>
				<? }?>
					<p><i class="fa fa-fw fa-tripadvisor"></i><?=$OR->score;?></p>
			</div>
			
		<?
				
			 } ?>
			<hr>
<?
	$j++;
	$qcnt++;
	$thisstep++;
	}
	if($thisstep>0){
?>
	<p class="bg-orange"><?=$q;?></p>
<?
	}
	if($qcnt<$minq){
		$c=count($words)-1;
		$newmember=$words[$c];
		if(count($words)>0){
			array_pop($words);
			array_push($newwords,$newmember);
			if(count($words)>0){
				$q="+".implode(" +",$words)." ".implode(" ",$newwords);
			}else{
				$q=implode(" ",$newwords);
			}
		}else{
			break;
		}
	}
}
?>		</div>
		<div class="col-md-6">
			<div class="callout callout-success">
				<h4>جستجو بر اساس پاسخ ها</h4>
		</div>
<?
	$words=$wordsorig;
	unset($newwords);
	$newwords=array();
	$q="+".implode(" +",$words);
	$j=1;
	$qcnt=0;
while($qcnt<$minq){
	$qneed=$minq-$qcnt;
	$thisstep=0;
	$result=$db->query("select tbl,tbl_qid,MATCH (q) AGAINST('$q' IN BOOLEAN MODE) as score from nlp_questions where MATCH (question) AGAINST('$q' IN BOOLEAN MODE) order by score desc limit 0,$qneed");
	while($OR=$result->fetch(PDO::FETCH_OBJ)){
		$tbl=$OR->tbl;
		$id=$OR->tbl_qid;
		$result2=$db->query("select q,ans from $tbl where id='$id'");
		$OR2=$result2->fetch(PDO::FETCH_OBJ);
		$qu=$OR2->q;
		$ans=$OR2->ans;
		$qu=$OR->q;
		$ans=$OR->ans;
		$id=$OR->id;
		$qu=str_replace("ك","ک",$qu);
		$qu=str_replace("ي","ی",$qu);
		$ans=str_replace("ك","ک",$ans);
		$ans=str_replace("ي","ی",$ans);
		foreach($words as $rw){
			$qu=str_replace($rw,"<span class='text-orange'>$rw</span>",$qu);
			$ans=str_replace($rw,"<span class='text-orange'>$rw</span>",$ans);
		}
		foreach($newwords as $rw){
			$qu=str_replace($rw,"<span class='text-orange'>$rw</span>",$qu);
			$ans=str_replace($rw,"<span class='text-orange'>$rw</span>",$ans);
		}

		$len=strlen($qu)+strlen($ans);
		if($len<$maxlen){
?>
			<div>
				<p class="text-green"><?=$j;?><i class="fa fa-fw fa-question-circle"></i><?=$qu;?></p>
				<p><?=$ans;?></p>
				<p><i class="fa fa-fw fa-tripadvisor"></i><?=$OR->score;?></p>
			</div>
		<? }else{
						
		 ?>
		 	<div id="dla_<?=$id;?>">
				<p class="text-green"><?=$j;?><i class="fa fa-fw fa-question-circle"></i><?=$qu;?></p>
				<p><?=$ans;?></p>
				<p><button type="button" id="bla_<?=$id;?>" class="btn btn-default btn-xs">نمایش مختصر</button></p>
				<p><i class="fa fa-fw fa-tripadvisor"></i><?=$OR->score;?></p>
			</div>
			<div id="dsa_<?=$id;?>">
				<? if(strlen($qu)<$maxlen){
						$l=$maxlen-strlen($qu);
						$ans=substr($ans,0,$l)." ...";
				?>
					<p class="text-green"><?=$j;?><i class="fa fa-fw fa-question-circle"></i><?=$qu;?></p>
					<p><?=$ans;?></p>
					<p><button type="button" id="bsa_<?=$id;?>" class="btn btn-default btn-xs">نمایش کامل</button></p>
				<? }else{
						$qu=substr($qu,0,$maxlen)." ...";
				?>
					<p class="text-green"><?=$j;?><i class="fa fa-fw fa-question-circle"></i><?=$qu;?></p>
					<p><button type="button" id="bsa_<?=$id;?>" class="btn  btn-default btn-xs">نمایش کامل</button></p>
				<? }?>
					<p><i class="fa fa-fw fa-tripadvisor"></i><?=$OR->score;?></p>
			</div>
			
		<?
				
			 } ?>
			<hr>
<?
	$j++;
	$qcnt++;
	$thisstep++;
	}
	if($thisstep>0){
?>
	<p class="bg-orange"><?=$q;?></p>
<?
	}
	if($qcnt<$minq){
		$c=count($words)-1;
		$newmember=$words[$c];
		if(count($words)>0){
			array_pop($words);
			array_push($newwords,$newmember);
			if(count($words)>0){
				$q="+".implode(" +",$words)." ".implode(" ",$newwords);
			}else{
				$q=implode(" ",$newwords);
			}
		}else{
			break;
		}
	}
}
?>	
		</div>
<? }?>
	</div>
	</div>
</div>
<script>
$('div[id^=dl]').hide();
$('button[id^=bs]').click(
	function(){
		id1="#"+$(this).attr("id").replace("bs","ds");
		id2="#"+$(this).attr("id").replace("bs","dl");
		$(id1).slideUp(1000);
		$(id2).slideDown(1000);	
	}
);
$('button[id^=bl]').click(
	function(){
		id1="#"+$(this).attr("id").replace("bl","ds");
		id2="#"+$(this).attr("id").replace("bl","dl");
		$(id2).slideUp(1000);
		$(id1).slideDown(1000);	
	}
);

</script>